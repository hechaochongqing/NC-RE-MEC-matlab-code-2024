function varargout = detect_mice(varargin)
% DETECT_MICE MATLAB code for detect_mice.fig
%      DETECT_MICE, by itself, creates a new DETECT_MICE or raises the existing
%      singleton*.
%
%      H = DETECT_MICE returns the handle to a new DETECT_MICE or the handle to
%      the existing singleton*.
%
%      DETECT_MICE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DETECT_MICE.M with the given input arguments.
%
%      DETECT_MICE('Property','Value',...) creates a new DETECT_MICE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before detect_mice_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to detect_mice_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help detect_mice

% Last Modified by GUIDE v2.5 14-Jul-2019 10:25:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @detect_mice_OpeningFcn, ...
                   'gui_OutputFcn',  @detect_mice_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before detect_mice is made visible.
function detect_mice_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to detect_mice (see VARARGIN)

% Choose default command line output for detect_mice
handles.output = hObject;
addpath('./mmread');
set(handles.edit_length,'string',50);
set(handles.edit_cm_pixel,'string',0.2);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes detect_mice wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = detect_mice_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in load_pushbutton.
function load_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to load_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 [filename pathname] = uigetfile('*.avi;*.mp4;*.mpg');
 %info = mmfileinfo([pathname filename]);
 %videoFReader = vision.VideoFileReader([pathname filename]);
 tic
     video = mmread([pathname filename]); 
 toc
 
 total_frames = video.nrFramesTotal;
 axes(handles.axes1);
 imshow(video.frames(1).cdata,video.frames(1).colormap);
 
set(handles.edit1_x,'string',1);
set(handles.edit1_y,'string',1);
set(handles.edit2_x,'string',video.width);
set(handles.edit2_y,'string',video.height);
 
 
 handles.Frames = video.frames;
 handles.filename = filename;
 handles.pathname = pathname;
 guidata(hObject,handles);

 
function videodata = get_frames(v)
videodata = [];
tic
ii = 0;
% while   ~isDone(v)
%     %frame = readFrame(v);
%     if ii ==200
%        break;
%     end
%     ii = ii+1;
%     
%     if mod(ii,1000)==0
%        ii
%     end
%     frame = rgb2gray(v());
%     videodata = cat(3,videodata,frame);
% end
toc


% --- Executes on button press in rect_pushbutton.
function rect_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to rect_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(hObject,handles);
axes(handles.axes1);
hold on;
if isfield(handles,'rectangle')
    if ~isempty(handles.rectangle)
        delete(handles.rectangle)
    end
end
h = drawrectangle();
postion = h.Position;
delete(h);

%postion = round(position); 
%handles.rectangle = scatter([postion(1) postion(1)+postion(3) ],[postion(2) postion(2)+postion(4)]);

 x1 = postion(1);
 x2 = postion(1)+postion(3);
 y1 = postion(2);
 y2 = postion(2)+postion(4);

handles.rectangle_xy = [[x1 x1 x2 x2 x1];[y1 y2 y2 y1 y1]];
handles.rectangle =  plot([x1 x1 x2 x2 x1],[y1 y2 y2 y1 y1]);

set(handles.edit1_x,'string',round(postion(1)));
set(handles.edit1_y,'string',round(postion(2)));
set(handles.edit2_x,'string',round(postion(1)+postion(3)));
set(handles.edit2_y,'string',round(postion(2)+postion(4)));
guidata(hObject,handles);



% --- Executes on button press in detect_pushbutton.
function detect_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to detect_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(hObject,handles);
Frames = handles.Frames;
axes(handles.axes1);
hold on;
thresh = str2num(get(handles.edit_threshold,'string'));
centers = [];

x1 = str2num(get(handles.edit1_x,'string' ));
y1 = str2num(get(handles.edit1_y,'string' ));
x2 = str2num(get(handles.edit2_x,'string' ));
y2 = str2num(get(handles.edit2_y,'string' ));
rect_x = [x1 x1 x2 x2 x1];
rect_y = [y1 y2 y2 y1 y1];

handles.scatterH = [];
handles.showH = [];
handles.rectangle = [];
if ~isempty(Frames(1).colormap)
   msgbox('error file types, use another data', 'error');
end
center_x_before = NaN;
center_y_before = NaN;
for ii = 1:length(Frames)
    frame = rgb2gray(Frames(ii).cdata);
    frame2 = frame(y1:y2,x1:x2);
    [row,col] = find((frame2)>thresh);
    center_x = mean(col);
    center_y = mean(row);
    if isnan(center_x)
        center_x = center_x_before;
        center_y = center_y_before;
    end
    centers = [centers;[center_x+x1-1,center_y+y1-1]];
    if isempty(handles.scatterH)
       handles.showH = imshow(frame);
       handles.scatterH = scatter(center_x+x1-1,center_y+y1-1,'r+');
       handles.rectangle = plot(rect_x,rect_y,'r');
    else
        set(handles.scatterH,'XData',center_x+x1-1,'YData',center_y+y1-1);
        set(handles.showH,'cData',frame);
        set(handles.rectangle,'XData',rect_x,'YData',rect_y);
    end
        center_x_before = center_x;
        center_y_before = center_y;
    pause(0.000001);
end
handles.centers = centers;
guidata(hObject,handles);



function edit1_x_Callback(hObject, eventdata, handles)
% hObject    handle to edit1_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1_x as text
%        str2double(get(hObject,'String')) returns contents of edit1_x as a double


% --- Executes during object creation, after setting all properties.
function edit1_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_y_Callback(hObject, eventdata, handles)
% hObject    handle to edit1_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1_y as text
%        str2double(get(hObject,'String')) returns contents of edit1_y as a double


% --- Executes during object creation, after setting all properties.
function edit1_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_x_Callback(hObject, eventdata, handles)
% hObject    handle to edit2_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2_x as text
%        str2double(get(hObject,'String')) returns contents of edit2_x as a double


% --- Executes during object creation, after setting all properties.
function edit2_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_y_Callback(hObject, eventdata, handles)
% hObject    handle to edit2_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2_y as text
%        str2double(get(hObject,'String')) returns contents of edit2_y as a double


% --- Executes during object creation, after setting all properties.
function edit2_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in edit_threshold.
function edit_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to edit_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function edit_threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton_save.
function pushbutton_save_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(hObject,handles);
filename = handles.filename;
pathname = handles.pathname;
distance_unit = str2double(get(handles.edit_cm_pixel,'String'));
centers = handles.centers;
uisave({'centers','distance_unit'},[pathname '/' filename(1:end-4) '_trajectory.mat']);


% --- Executes on button press in pushbutton_measure.
function pushbutton_measure_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_measure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
guidata(hObject, handles);
axis(handles.axes1);
[x1,y1] = ginput(1);
hold on;
x1 = round(x1);
y1 = round(y1);
hs1 = scatter(x1,y1,'r.');
[x2,y2] = ginput(1);

x2 = round(x2);
y2 = round(y2);
hs2 = scatter(x2,y2,'r.');
delete(hs1);
delete(hs2);
plot([x1,x2],[y1,y2],'g');
length_draw = sqrt((x2-x1)^2+(y2-y1)^2);
length_cm = str2double(get(handles.edit_length,'String'));
set(handles.edit_cm_pixel,'string',num2str(length_cm/length_draw));

guidata(hObject, handles);



function edit_length_Callback(hObject, eventdata, handles)
% hObject    handle to edit_length (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_length as text
%        str2double(get(hObject,'String')) returns contents of edit_length as a double


% --- Executes during object creation, after setting all properties.
function edit_length_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_length (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_cm_pixel_Callback(hObject, eventdata, handles)
% hObject    handle to edit_cm_pixel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_cm_pixel as text
%        str2double(get(hObject,'String')) returns contents of edit_cm_pixel as a double


% --- Executes during object creation, after setting all properties.
function edit_cm_pixel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_cm_pixel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
