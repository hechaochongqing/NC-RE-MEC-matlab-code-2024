clear all;
%[filename1 pathname1] = uigetfile('*.mat','Please select the trajectory mat file');
[filename2 pathname2] = uigetfile('*.mat','Please select the LFP mat file');
[filename3 pathname3] = uigetfile('*.mat','Please select the spiking mat file');


time = [270.72555	315.94539
580.38315	655.33995
728.08491	825.16011
1876.27563	1957.62219
2118.59499	2282.76267
2372.95659	2490.42987];

fre_low = 0.5;
fre_high = 4;
time_start = time(:,1);
time_end = time(:,2);



lfp_data = load([pathname2 filename2]);
spike_data = load([pathname3 filename3]);


%%
lfp_all = fieldnames(lfp_data);
%str_pattern = 'CSC[\d]{1,}_[\d]{4}_[\d]{1,4}';
str_pattern = 'CSC[\d]{1,}[_]{0,1}[0]{0,1}[0]{0,1}[0]{0,1}[1]{0,1}_[\d]{1,3}';

lfg_values = cell(0);
lfg_values2 = [];

t = 0;
for ii = 1:length(lfp_all)
    [subpar,start_ind,end_ind] =  regexp(lfp_all{ii},str_pattern,'match');
        if ~isempty(start_ind)
             if ~ismember(subpar,lfg_values)
                   t = t+1;
                   lfg_values{t} = subpar{1};
                   temp0 = regexp(subpar{1},'CSC[\d]{1,}','match');
                   temp = regexp(temp0{1},'[\d]{1,}','match');
                   lfg_values2(t) = str2num(temp{1});
             end
        end
end
%%
spike_data_all = fieldnames(spike_data);
% 'tiral_1_sorting_tt_03_02'
str_pattern2 = '_tt_[\d]{1,3}[_]{0,1}[\d]{1,3}';
spike_values1 = cell(0);
spike_values2 = cell(0);

t = 0;
for ii = 1:length(spike_data_all)
    [subpar,start_ind,end_ind] =  regexp(spike_data_all{ii},str_pattern2,'match');
    if ~isempty(start_ind)
       t = t+1;
       spike_values1{t} = spike_data_all{ii};
       spike_values2{t} = subpar{1}(5:end);
    end
end
%%
data__save_all = [];
t1 = cell(0);
jj = 0;


pval_all = zeros([length(spike_values2),length(time_start) ]);
preferred_phase_all =zeros([length(spike_values2),length(time_start) ]);
strength_locking_all = zeros([length(spike_values2),length(time_start) ]);
for ii = 1:length(spike_values2)
      aa =  regexp(spike_values2{ii} ,'_','split');
      spike = spike_values1{ii};
     
          jj = jj+1;
          ind_2_find = str2num(aa{1});
          lfp_string = lfg_values{find(ind_2_find == lfg_values2)};
          
          lfp_data_single = eval(['lfp_data.' lfp_string]);
          data_ts_single = eval(['lfp_data.' lfp_string '_ts']);
          data_step_single = eval(['lfp_data.' lfp_string '_ts_step']);
          spike_data_single = eval(['spike_data.' spike ]);
          
       
          %sss = ['cal_phase(' 'lfp_data.' lfg_string ',lfp_data.' [lfg_string '_ts'] ',lfp_data.' [lfg_string '_ts_step, speed ,speed_threshold,fs,centers,time_start_index,spike_data.' spike] ')'];
         data_save_temp = [];     
         
         [t,LFP] = convert_timeLFP(lfp_data_single,data_ts_single,data_step_single);
         Fs=1/data_step_single(1);
         [fb,fa] = butter(2,[fre_low fre_high]*2/Fs,'bandpass');  % theta 4~12   % gamma 25~48 60~120
         dataFiltered = filtfilt(fb,fa,LFP);
         LFPdataFiltered=hilbert(dataFiltered);
         

               t1{jj} = spike ;
               
          for k = 1:length(time_start)
                time_start_temp = time_start(k);
                time_end_temp = time_end(k);
     
                [pval,preferred_phase,strength_locking,phase] = eval(['cal_phase3(LFPdataFiltered,t, spike_data_single, time_start_temp, time_end_temp)']);
               data_save_temp =[data_save_temp; [pval preferred_phase strength_locking]];
               
               phase_all{ii,k} = phase;
               pval_all(ii,k) = pval;
               preferred_phase_all(ii,k) = preferred_phase;
               strength_locking_all(ii,k) = strength_locking;
          end
 
          
end

save_data.phase_all = phase_all;
save_data.pval_all = [pval_all mean(pval_all,2)];
save_data.preferred_phase_all = [preferred_phase_all mean(preferred_phase_all,2)];
save_data.strength_locking_all =[strength_locking_all mean(strength_locking_all,2)];
save_data.names = t1;
%%
%%
angle_ind=-pi:pi/20:pi;
angle_ind2=pi:pi/20:(pi+2*pi);
for ii = 1:size(phase_all,1)
    figure(ii);
    name = t1{ii};
    nelements_mean = [];
     for kk = 1:size(phase_all,2)
             subplot(3,ceil((size(phase_all,2)+1)/3),kk);

         angle_value = phase_all{ii,kk};
         [ nelements,centers] = hist(angle_value,angle_ind);
         nelements_mean = [nelements_mean ; nelements];
         bar(centers,nelements*100/length(angle_value));
         set(gca,'xtick',-pi:pi/2:pi);
         title(name,  'Interpreter', 'none');
     end
     nelements_mean = mean(nelements_mean,1);
     subplot(3,ceil((size(phase_all,2)+1)/3),kk+1);
              bar(centers,nelements_mean*100/length(angle_value));
         set(gca,'xtick',-pi:pi/2:pi);
         title(name,  'Interpreter', 'none');
end
%%
[Filename, Pathname] = uiputfile('temp_save.mat','Save Selected Data'); 
if Filename==0
    return
end
string_memorial = 'data pattern: channels * (number_of_times+1); the last column is average';
save([Pathname '\' Filename], 'save_data','string_memorial');

%LastName = {'name'p';'preferred_phase';'strength_locking'};
% p_value = data__save_all(:,1);
% preferred_phase = data__save_all(:,2);
% strength_locking = data__save_all(:,3);
% names = t1';
% T = table(t1', p_value, preferred_phase,  strength_locking);
% writetable(T,'table.csv');

