function [t,LFP] = convert_timeLFP(csc_data,time,time_step)
time_start = time(1);
t = [0:length(csc_data)-1]*time_step(1) + time_start;
LFP = csc_data;
end