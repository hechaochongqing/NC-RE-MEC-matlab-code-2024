function [pval,preferred_phase,strength_locking,alpha] = cal_phase3(LFPdataFiltered,t, spike_time, time_start, time_end)


spike_time2 = [];
for ii = 1:length(time_start)
     % spike_time2 = [spike_time2;spike_time(find(spike_time >=time_start(ii) +tiral_1_sorting_tt_04(1) & spike_time<time_end(ii)+tiral_1_sorting_tt_04(1)))];
     spike_time2 = [spike_time2; spike_time(find(spike_time >=time_start(ii) & spike_time<time_end(ii)))];
end
% spike_time(spike_time < time_start+tiral_1_sorting_tt_04(1)) = [];
% spike_time(spike_time>time_end+tiral_1_sorting_tt_04(1)) = [];
spike_time = spike_time2;
points_st = [];  
lfp_ind = [];
for p=1:length(spike_time)
        points_st=[points_st spike_time(p)];  % save the time for spike
        [~, points_lfp_ind]  = min(abs(spike_time(p) - t));
        lfp_ind = [lfp_ind points_lfp_ind];
end   
%%
complex_value_all = LFPdataFiltered(lfp_ind);        
phase_all = angle(complex_value_all);
% %%
% angle_ind=-pi:pi/20:pi;
% angle_ind2=pi:pi/20:(pi+2*pi);
% angle_value = phase_all;
% [nelements,centers] = hist(angle_value,angle_ind);
% figure,
% bar(centers,nelements*100/length(angle_value));
% set(gca,'xtick',-pi:pi/2:pi);
% title(name,  'Interpreter', 'none');
%%
locking_value = mean(exp(angle(LFPdataFiltered(lfp_ind))*1i));       
preferred_phase = angle(locking_value);
strength_locking = abs(locking_value);
alpha = phase_all;
r =  abs(mean(exp(alpha*1i)));
n = length(alpha);
R = n*r;
z = R^2 / n;
pval = exp(sqrt(1+4*n+4*(n^2-R^2))-(1+2*n)) ;
