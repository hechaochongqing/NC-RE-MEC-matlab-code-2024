function  [gamma_power_phase_prob, MIvalue] = cal_mi(LFPdataFilteredTheta,LFPdataFilteredGamma,Fs,angle_ind,angle_ind2)

% angle_ind=-pi:pi/20:pi;
% angle_ind2=pi:pi/20:(pi+2*pi);
ind_length=length(angle_ind)-1;
p_unif = pdf('uniform',0:1/ind_length:1,0,1)/ind_length;
p_unif=p_unif(1:end-1);
factor_value=log(ind_length);
%MIvalue=zeros(size(LFPdata{j},2),2);

         
        LFPdataTheta=LFPdataFilteredTheta;
        LFPdataGamma=LFPdataFilteredGamma;    
        
        gamma_power=abs(LFPdataGamma).^2;
        theta_phase=angle(LFPdataTheta);
        [bincounts,ind] = histc(theta_phase,angle_ind);
        gamma_power_phase=zeros(1,length(angle_ind)-1);
        for i=1:length(angle_ind)-1
            phase_index=find(ind==i);
            gamma_power_phase(i)=mean(gamma_power(phase_index));
        end        
        gamma_power_phase_prob=gamma_power_phase/sum(gamma_power_phase);
        Q = p_unif ./sum(p_unif);
        P = gamma_power_phase_prob ./repmat(sum(gamma_power_phase_prob,2),[1 size(gamma_power_phase_prob,2)]);
        temp =  P.*log(P./repmat(Q,[size(P,1) 1]));
        temp(isnan(temp))=0;
        KLdist = sum(temp,2);        
        MIvalue = KLdist/factor_value;
     


%%

% [Filename, Pathname] = uiputfile('MI_before_after.txt','Save Selected Data'); 
% if Filename==0
%     return
% end
% FileID = fopen([Pathname Filename(1:end-4) '.txt'],'w');
% fprintf(FileID,'%3.8f %3.8f\n',MIvalue');
% fclose(FileID);