clear all;
close all;
% with speed
 time_set = [
4757.07293	4825.88573
4845.87421	4900.92445
4913.37629	4987.75965
5021.83837	5068.04125
5343.62013	5391.13373
6306.67165	6345.33789
6637.30077	6739.20925
6794.58717	6822.11229
6850.94813	6883.38845
7053.78205	7099.98493
];

Fs_downsample_ratio = 100;
%%
[filename pathname ] = uigetfile('*.mat');
data_all = load([pathname filename]);
lfp_all = fieldnames(data_all);
str_pattern = 'CSC[\d]{1,}[_]{0,1}[0]{0,1}[0]{0,1}[0]{0,1}[1]{0,1}_[\d]{1,3}';

ti = 0;
data_names = cell(0);
for ii = 1:length(lfp_all)
    [subpar,start_ind,end_ind] =  regexp(lfp_all{ii},str_pattern,'match');
        if ~isempty(start_ind) & end_ind-start_ind+1 == length(lfp_all{ii}) 
            ti = ti+1;
              data_names{ti} = lfp_all{ii};
        end
end

MIvalue_split =[];
gamma_power_phase_prob_split = [];
% MIvalue_all =zeros([length(data_names),1]);
for k = 1:length(data_names)
            %%
            time_start =eval(['data_all.' data_names{k} '_ts']) ;
            time_start = time_start(1);
            time_step =eval( ['data_all.' data_names{k} '_ts_step']);
            time_step = time_step(1);
            data = eval(['data_all.' data_names{k}]);
            t = time_start:time_step:(length(data)-1)*time_step+time_start;
           %%
%              t_start = time(:,1)+time_start;  %begin time points
%              t_end =  time(:,2)+time_start;   %end time points

            LFPdata_split = [];
            LFPdata_split_shuffle = [];
            time_split = [];
            time_start_set = time_set(:,1);
            time_end_set = time_set(:,2);
            ff = 0;
            for jj = 1:length(time_start_set)
                        [~,ind_select_temp] = find( t>=time_start_set(jj) & t<=time_end_set(jj));
                     if ~isempty(ind_select_temp)
                           ff = ff+1;
                           temp =  data(ind_select_temp); 
                           LFPdata_split{ff} = temp;
                           LFPdata_split_shuffle{ff} = temp(randperm(length(temp))); 
                           time_split_temp{ff} = t(ind_select_temp);
                     end   
            end

            if isempty(gamma_power_phase_prob_split)
                gamma_power_phase_prob_split = cell([length(data_names) length(LFPdata_split)]);
                gamma_power_phase_prob_shuffled = cell([length(data_names) length(LFPdata_split)]);
                MIvalue_split = zeros([length(data_names) length(LFPdata_split)]);
                MIvalue_split_shuffled = zeros([length(data_names) length(LFPdata_split)]); 
            end
            for ii = 1:length(LFPdata_split)
                        Fs = 1/time_step;
                        Fs = Fs/Fs_downsample_ratio;
                        
                        LFPdata = LFPdata_split{ii}; 
                        LFPdata = LFPdata(1:Fs_downsample_ratio:end);
                        [fb,fa] = butter(2,[0.5 4]*2/Fs,'bandpass');    %dleta filter
                        dataFiltered = filtfilt(fb,fa,LFPdata);
                        LFPdataFilteredTheta = hilbert(dataFiltered);
                        [fb,fa] = butter(2,[4 12]*2/Fs,'bandpass');
                        dataFiltered = filtfilt(fb,fa,LFPdata);          %theta filter
                        LFPdataFilteredGamma =  hilbert(dataFiltered);
                        %%
                        %shuffled data =
                        LFPdata_shuffled  = LFPdata_split_shuffle{ii};
                        LFPdata_shuffled = LFPdata_shuffled(1:Fs_downsample_ratio:end);
                         [fb,fa] = butter(3,[0.5 4]*2/Fs,'bandpass');    %delta filter     0.5 4
                        dataFiltered_shuffled  = filtfilt(fb,fa,LFPdata_shuffled);
                        LFPdataFilteredTheta_shuffled = hilbert(dataFiltered_shuffled);
                        [fb,fa] = butter(2,[4 12]*2/Fs,'bandpass');  %               4 12
                        dataFiltered_shuffled = filtfilt(fb,fa,LFPdata_shuffled);          %theta filter
                        LFPdataFilteredGamma_shuffled =  hilbert(dataFiltered_shuffled);
                        
                        %%
                       
                        angle_ind=-pi:pi/20:pi;
                        angle_ind2=pi:pi/20:(pi+2*pi);
                        ind_length=length(angle_ind)-1;
                        [gamma_power_phase_prob,MI] = cal_mi(LFPdataFilteredTheta,LFPdataFilteredGamma,Fs,angle_ind,angle_ind2);
                        [gamma_power_phase_prob_shuffled, MI_shuffled] = cal_mi(LFPdataFilteredTheta_shuffled,LFPdataFilteredGamma_shuffled,Fs,angle_ind,angle_ind2);

                        MIvalue_split(k,ii) = MI;
                       gamma_power_phase_prob_split{k,ii} = gamma_power_phase_prob;
                       time_split{k,ii} =  time_split_temp{ii};
                       
                       MIvalue_split_shuffled(k,ii) = MI_shuffled;
                       gamma_power_phase_prob_split_shuffled{k,ii} = gamma_power_phase_prob_shuffled;
                       

            end
 end
%% each time series plot a prob
for time_series = 1:size(gamma_power_phase_prob_split,2)
    %figure(time_series);
    for ii =1:size(gamma_power_phase_prob_split,1)
         channel_name = data_names{ii};
         gamma_power_phase_prob_temp = gamma_power_phase_prob_split{ii,time_series};
         MIvalue_temp = MIvalue_split(ii,time_series);
         
       % subplot(4,ceil(size(gamma_power_phase_prob_split,1)/2),ii);
      %  bar([angle_ind(1:end-1) angle_ind2(1:end-1)]/(2*pi)*360,[gamma_power_phase_prob_temp gamma_power_phase_prob_temp]);
      %  set(gca,'xlim',[-180 540]);
        %set(gca,'xtick',-180:180:540);
        %set(gca,'ylim',[0 0.04]);
        %title([channel_name, ', MI: ' num2str(MIvalue_temp)],'Interpreter','none');
       % ylabel('Theta power');
        %xlabel('delta phase');
        
        %subplot(4,ceil(size(gamma_power_phase_prob_split,1)/2),ii+2*ceil(size(gamma_power_phase_prob_split,1)/2));
        gamma_power_phase_prob_temp_shuffled = gamma_power_phase_prob_split_shuffled{ii,time_series};
        MIvalue_temp = MIvalue_split_shuffled(ii,time_series);
        %bar([angle_ind(1:end-1) angle_ind2(1:end-1)]/(2*pi)*360,[gamma_power_phase_prob_temp_shuffled gamma_power_phase_prob_temp_shuffled]);
       % set(gca,'xlim',[-180 540]);
       % set(gca,'xtick',-180:180:540);
        %set(gca,'ylim',[0 0.04]);
       % title([channel_name, ', shuffled MI: ' num2str(MIvalue_temp)],'Interpreter','none');
      %  ylabel('Theta power');
       % xlabel('delta phase');
        
    end
end

%% 
% calculate the average for each channel 
gamma_power_phase_prob_channel_ave = [];
gamma_power_phase_prob_channel_shuffled_ave = [];
for ii =1:size(gamma_power_phase_prob_split,1)
    gamma_power_phase_prob_channel = [];
    
     for time_series = 1:size(gamma_power_phase_prob_split,2)
         channel_name = data_names{ii};
         gamma_power_phase_prob_temp = gamma_power_phase_prob_split{ii,time_series};
         gamma_power_phase_prob_channel = [gamma_power_phase_prob_channel;gamma_power_phase_prob_temp];
         gamma_power_phase_prob_temp_shuffled = gamma_power_phase_prob_split_shuffled{ii,time_series};
         gamma_power_phase_prob_channel_shuffled  = [gamma_power_phase_prob_temp_shuffled;gamma_power_phase_prob_temp_shuffled];
     end
     
    gamma_power_phase_prob_channel_ave = [ gamma_power_phase_prob_channel_ave ; mean(gamma_power_phase_prob_channel,1)];
    gamma_power_phase_prob_channel_shuffled_ave = [gamma_power_phase_prob_channel_shuffled_ave;mean(gamma_power_phase_prob_channel_shuffled,1)];
    % for average view
    %figure,plot(gamma_power_phase_prob_channel');
    %hold on;
    %plot(mean(gamma_power_phase_prob_channel,1),'r','LineWidth',2);
    %channel_name = data_names{ii}; 
    %title(channel_name,'Interpreter','none');
end
%%
% the final average bar
h = figure(1001);
max_point = [];

for ii = 1:size(gamma_power_phase_prob_channel_ave,1)
         subplot(2,ceil(size(gamma_power_phase_prob_split,1)/2),ii);
         channel_name = data_names{ii};

         gamma_power_phase_prob_temp = gamma_power_phase_prob_channel_ave(ii,:);
        bar([angle_ind(1:end-1) angle_ind2(1:end-1)]/(2*pi)*360,[gamma_power_phase_prob_temp gamma_power_phase_prob_temp]);
        set(gca,'xlim',[-180 540]);
        set(gca,'xtick',-180:180:540);
        set(gca,'ylim',[0 0.04]);
        title([channel_name, ', ave_MI: ' num2str( mean(MIvalue_split(ii,:),2))],'Interpreter','none');
        ylabel('Theta power');
        xlabel('delta phase');
end
[~,I] = max(gamma_power_phase_prob_channel_ave,[],2);
max_phase = angle_ind(I);


h = figure(1002);
for ii = 1:size(gamma_power_phase_prob_channel_shuffled_ave,1)
         subplot(2,ceil(size(gamma_power_phase_prob_split_shuffled,1)/2),ii);
         channel_name = data_names{ii};

         gamma_power_phase_prob_temp = gamma_power_phase_prob_channel_shuffled_ave(ii,:);
        bar([angle_ind(1:end-1) angle_ind2(1:end-1)]/(2*pi)*360,[gamma_power_phase_prob_temp gamma_power_phase_prob_temp]);
        set(gca,'xlim',[-180 540]);
        set(gca,'xtick',-180:180:540);
        set(gca,'ylim',[0 0.04]);
        title([channel_name, ', shuffled ave_MI: ' num2str( mean(MIvalue_split_shuffled(ii,:),2))],'Interpreter','none');
        ylabel('Theta power');
        xlabel('delta phase');
end

[~,I] = max(gamma_power_phase_prob_channel_shuffled_ave,[],2);
max_phase_shuffled = angle_ind(I);
%%
save_data.gamma_power_phase_prob_split  = gamma_power_phase_prob_split;
save_data.channelnames =  data_names;
save_data.angle_ind  = angle_ind ;
save_data.angle_ind2 = angle_ind2 ;
save_data. gamma_power_phase_prob_channel_ave = gamma_power_phase_prob_channel_ave;
save_data.MIvalue_split = MIvalue_split;
save_data.MIvalue_average = mean(MIvalue_split,2);
save_data.MIvalue_split_shuffled = MIvalue_split_shuffled;
save_data.MIvalue_average_shuffled  =  mean(MIvalue_split_shuffled,2) ;
save_data.max_phase = max_phase;
save_data.max_phase_shuffled = max_phase_shuffled;



[Filename, Pathname] = uiputfile('MI_value.mat','Save Selected Data'); 
if Filename==0
    return
end
save([Pathname '\' Filename], 'save_data');
MIvalue = [save_data.MIvalue_split  save_data.MIvalue_average];
FileID = fopen([Pathname Filename(1:end-4) '.txt'],'w');
str_offset = '%3.8f';
for ii = 1:size(MIvalue,2)-1
    str_offset = [str_offset  '\t%3.8f'];
end
str_offset = [str_offset ' \n'];
fprintf(FileID, str_offset, MIvalue');
fclose(FileID);


