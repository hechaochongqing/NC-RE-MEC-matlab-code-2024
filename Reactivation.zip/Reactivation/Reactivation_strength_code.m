c_list=who;
SpikeData=cell(1,1);
n=1;
for i=1:length(c_list)
    if c_list{i}(1)=='T'
        SpikeData{n}=eval(c_list{i});  
        n=n+1;
    end
end
%

clear firing_rate_template firing_rate_match;
Binsize=0.1;
j=3; % The j-th trial as template ��trainning trials��
for i=1:length(SpikeData)
    timevalues =time_marker(j,1):Binsize:time_marker(j,2);	        
    ind1=find(SpikeData{i}>=timevalues(1));
    ind2=find(SpikeData{i}<=timevalues(end));
    ind=intersect(ind1,ind2);        
    firing_rate_template(i,:)=(histc(SpikeData{i}(ind),timevalues))/Binsize;
end
j=8; % The j-th trial as match��post sleep��
for i=1:length(SpikeData)
    timevalues =time_marker(j,1):Binsize:time_marker(j,2);	        
    ind1=find(SpikeData{i}>=timevalues(1));
    ind2=find(SpikeData{i}<=timevalues(end));
    ind=intersect(ind1,ind2);        
    firing_rate_match(i,:)=(histc(SpikeData{i}(ind),timevalues))/Binsize;
end
firing_rate_match_sum=sum(firing_rate_match,2);
ind_zero=find(firing_rate_match_sum==0);
ind_valid=setdiff(1:length(SpikeData),ind_zero);
firing_rate_template=firing_rate_template(ind_valid,:);
firing_rate_match=firing_rate_match(ind_valid,:);
%
zscore_rate=firing_rate_template;
for k=1:size(firing_rate_template,1)
    data_st=firing_rate_template(k,:);
    zscore_rate(k,:)=(data_st-mean(data_st))/std(data_st);
end

data_cc_template=(zscore_rate*zscore_rate')/size(zscore_rate,2);

zscore_rate_match=firing_rate_match;
for k=1:size(firing_rate_match,1)
    data_st=firing_rate_match(k,:);
    zscore_rate_match(k,:)=(data_st-mean(data_st))/std(data_st);
end

data_cc_match=(zscore_rate*zscore_rate')/size(zscore_rate,2);
%
q=size(zscore_rate,2)/size(zscore_rate,1);
lambda_max=(1+sqrt(1/q))^2;
lambda_min=(1-sqrt(1/q))^2;

[E, D] = eig(data_cc_template); 
[dummy,order] = sort(diag(-D));
E = E(:,order);
d = diag(D);
dsqrtinv = real(d.^(-0.5)); 
Dsqrtinv = diag(dsqrtinv(order));
D = diag(d(order));
V = Dsqrtinv*E';

%
d2=d(order);
signal_n=length(find(d2>lambda_max));
%
time=time_marker(j,1):Binsize:time_marker(j,2);
figure;
Rvalue=zeros(signal_n,size(zscore_rate_match,2));
for f=1:signal_n
    k=f;
    P1=E(:,k)*(E(:,k))';    
    for t=1:size(zscore_rate_match,2)
        data_point=zscore_rate_match(:,t);
        Rvalue(f,t)=data_point'*P1*data_point;
    end    
    
    s2=subplot(signal_n,1,f);
    set(gca,'FontSize',20);
    plot(time,Rvalue(f,:),'k');
    ylabel(['R ' num2str(k)]);
    xlabel('Time (s)');
    if f==1
        title('Reactivation strength');
    end
    max_y(f)=max(Rvalue(f,:));
    %set(gca,'Ylim',[0 max(Rvalue(f,:))+10]);
    set(gca,'Xlim',[time_marker(j,1) time_marker(j,2)]);
end
for f=1:signal_n
    subplot(signal_n,1,f);
    set(gca,'Ylim',[0 200]);
end


%
[n_ZNR, m_ZNR]=size(ZNR);
NREM1=1:1:2*n_ZNR;
NREM1(1:2:2*n_ZNR)=ZNR(:,1);
NREM1(2:2:2*n_ZNR)=ZNR(:,2);
NREM=NREM1';
[n_ZW, m_ZW]=size(ZW);
w1=1:1:2*n_ZW;
w1(1:2:2*n_ZW)=ZW(:,1);
w1(2:2:2*n_ZW)=ZW(:,2);
wake=w1';
[n_ZR, m_ZR]=size(ZR);
r1=1:1:2*n_ZR;
r1(1:2:2*n_ZR)=ZR(:,1);
r1(2:2:2*n_ZR)=ZR(:,2);
REM=r1';

data_status{1}=NREM;
data_status{2}=REM;
data_status{3}=wake;

signal_n2{1}=find(d2>lambda_max);
signal_n2{2}=intersect(find(d2>lambda_max*0.4),find(d2<lambda_max));
signal_n2{3}=find(d2<lambda_max*0.4);
%
clear Rvalue_conditions;
for s=1:length(signal_n2)
    ns=signal_n2{s};
    Rvalue2=zeros(length(ns),size(zscore_rate_match,2));
    for f=1:length(ns)        
        P1=E(:,ns(f))*(E(:,ns(f)))';    
        for t=1:size(zscore_rate_match,2)
            data_point=zscore_rate_match(:,t);
            Rvalue2(f,t)=data_point'*P1*data_point;
        end           
    end
    for k=1:size(Rvalue2,1)
        for j=1:length(data_status)
            Rvalue_pool=[];
            for i=1:2:length(data_status{j})
                ind1=find(time>=data_status{j}(i));
                ind2=find(time<=data_status{j}(i+1));
                ind=intersect(ind1,ind2); 
                Rvalue_pool=[Rvalue_pool Rvalue2(k,ind)];
            end
            Rvalue_conditions{s,k}(j)=mean(Rvalue_pool);
        end
    end
end

% Rvalue_conditions varaible includes
% s: 3 reactivation criteria (D>lambda_max*0.8;lambda_max*0.4<D< lambda_max*0.8; lambda_max*0.4>D)
% k: the number of components in each reactivation criterion
% j: NREM, REM, Wake